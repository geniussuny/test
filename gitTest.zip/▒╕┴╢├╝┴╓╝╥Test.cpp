
#include	"windows.h"


typedef struct{
	unsigned char	sa;
	unsigned char	sb;
	unsigned short	sc;
	unsigned short	sd;
}TestStruct;

void main(void)
{
	unsigned int a = 0x12345678;
	unsigned int *pa = &a;
	unsigned char *pb = NULL;
	unsigned char *pc = NULL;
	unsigned short *pd = NULL;
	unsigned short *pe = NULL;
	TestStruct	*Struct_Test;

	Struct_Test = (TestStruct *)pa;

	pb = &(Struct_Test->sa);
	pc = &(Struct_Test->sb);
	pd = &(Struct_Test->sc);
	pe = &(Struct_Test->sd);


	//while(1);
}